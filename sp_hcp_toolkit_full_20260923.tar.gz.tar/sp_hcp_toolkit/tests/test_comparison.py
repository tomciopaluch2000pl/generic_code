import importlib.util
import pathlib
import unittest

spec=importlib.util.spec_from_file_location("compare_audits",pathlib.Path(__file__).resolve().parent.parent/"compare_audits.py")
compare=importlib.util.module_from_spec(spec)
spec.loader.exec_module(compare)


class ComparisonTests(unittest.TestCase):
    def result(self,**changes):
        data=dict(server_name="SP",pool="POOL",configured_maxprocess=4,status="COMPLETED_CLEAN",
                  scope_signature_sha256="abc",validate_cloud_extents="yes",audit_timing_basis="command_send_to_final_prompt",
                  audit_elapsed_seconds=100.0,audit_duration_hms="00:01:40",correlated_container_completions=200,
                  extents_inspected=1000,source="fixture")
        data.update(changes)
        return data

    def test_speedup_for_same_scope_and_settings(self):
        rows=list(compare.comparison_rows([self.result(),self.result(configured_maxprocess=8,audit_elapsed_seconds=50)]))
        self.assertEqual(rows[1][10],2.0)
        self.assertEqual(rows[1][11],50.0)

    def test_different_scope_or_failed_audit_has_no_speedup_claim(self):
        for changes in [dict(scope_signature_sha256="other"),dict(status="REVIEW_REQUIRED"),dict(audit_timing_basis="batch")]:
            with self.subTest(changes=changes):
                row=list(compare.comparison_rows([self.result(),self.result(**changes)]))[1]
                self.assertIsNone(row[10])
                self.assertIsNone(row[11])

    def test_fictional_results_are_labeled(self):
        row=list(compare.comparison_rows([self.result(is_fictional_example=True)]))[0]
        self.assertIn("FICTIONAL_DATA",row[12])
