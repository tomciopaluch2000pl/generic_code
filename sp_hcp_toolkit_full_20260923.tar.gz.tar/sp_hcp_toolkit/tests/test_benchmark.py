"""Offline benchmark lifecycle and portable credential regression tests."""
import contextlib
import io
import json
import os
from pathlib import Path
import shutil
import sys
import subprocess
import tempfile
import unittest
from unittest import mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import sp_hcp_audit as t
import benchmark_audits as b


class BenchmarkTests(unittest.TestCase):
    def setUp(self):
        self.temp=Path(tempfile.mkdtemp(prefix='sp_bench_test_'))
        self.fake=Path(__file__).parent/'fake_dsmadmc.py'
        self.fake.chmod(0o755)

    def tearDown(self):
        shutil.rmtree(str(self.temp))

    def execute(self,scenario='benchmark',extra=None):
        args=['benchmark','POOL_A','--dsmadmc',str(self.fake),'--out',str(self.temp/'report'),
              '--minutes','0.002','--poll-seconds','0.025','--cooldown-seconds','0',
              '--settle-seconds','0.03','--min-containers','1','--processes','10,20']+(extra or [])
        with mock.patch.dict(os.environ,{'SP_TEST_STATE':str(self.temp/'state'),'SP_TEST_SCENARIO':scenario}), \
             mock.patch('sys.stdin.isatty',return_value=True), \
             mock.patch('builtins.input',return_value='TESTADMIN'), \
             mock.patch.object(b.getpass,'getpass',return_value="test-$-quote'`-secret"), \
             contextlib.redirect_stdout(io.StringIO()):
            return t.main(args)

    def result(self):
        return json.loads((self.temp/'report/benchmark_result.json').read_text())

    def commands(self):
        return [json.loads(x) for x in (self.temp/'state/commands.jsonl').read_text().splitlines()]

    def test_timed_trials_cancel_parent_and_do_not_repeat_inventory(self):
        self.assertEqual(self.execute(),0)
        r=self.result()
        self.assertEqual(len(r['trials']),2)
        self.assertTrue(all(x['eligible'] for x in r['trials']))
        self.assertIsNone(r['active_parent_process_id'])
        self.assertFalse(r['namespace_deletion_assessed'])
        cmds=self.commands()
        self.assertEqual(sum(c.startswith('QUERY CONTAINER ') for c in cmds),1)
        self.assertEqual(sum(c.startswith('AUDIT CONTAINER ') for c in cmds),2)
        self.assertEqual(cmds.count('CANCEL PROCESS 41'),2)
        self.assertFalse(any(c=='CANCEL PROCESS 42' for c in cmds))
        self.assertTrue(all('WAIT=NO' in c for c in cmds if c.startswith('AUDIT CONTAINER ')))
        for p in (self.temp/'report').rglob('*'):
            if p.is_file(): self.assertNotIn(b"test-$-quote'`-secret",p.read_bytes())

    def test_disappeared_parent_is_not_success(self):
        self.assertEqual(self.execute('benchmark_vanish'),2)
        self.assertFalse(self.result()['trials'][0]['eligible'])
        self.assertEqual(sum(c.startswith('AUDIT CONTAINER ') for c in self.commands()),1)

    def test_unknown_submission_never_guesses_parent(self):
        with self.assertRaises(t.ToolError): self.execute('benchmark_no_id')
        self.assertFalse(any(c.startswith('CANCEL ') for c in self.commands()))
        self.assertEqual(sum(c.startswith('AUDIT CONTAINER ') for c in self.commands()),1)

    def test_workers_must_stop_before_next_trial(self):
        with self.assertRaises(t.ToolError): self.execute('benchmark_cancel_stuck')
        self.assertEqual(sum(c.startswith('AUDIT CONTAINER ') for c in self.commands()),1)
        self.assertEqual(self.result()['active_parent_process_id'],'41')

    def test_interruption_stops_identified_parent_without_next_trial(self):
        original=b.processes
        calls=[0]
        def interrupted(admin):
            calls[0]+=1
            if calls[0]==3:
                raise KeyboardInterrupt('synthetic interrupt')
            return original(admin)
        with mock.patch.object(b,'processes',side_effect=interrupted):
            with self.assertRaises(KeyboardInterrupt): self.execute()
        self.assertIsNone(self.result()['active_parent_process_id'])
        self.assertEqual(self.commands().count('CANCEL PROCESS 41'),1)
        self.assertEqual(sum(c.startswith('AUDIT CONTAINER ') for c in self.commands()),1)

    def test_wrong_pool_is_not_cancellable(self):
        record={'Process Description':'AUDIT CONTAINER','Process Status':'Storage pool OTHER, Total number of containers: 5'}
        with self.assertRaises(t.ToolError): b.parent_status(record,'POOL_A')

    def test_progress_transcribed_format(self):
        record={'Process Description':'AUDIT CONTAINER','Process Status':'Storage pool POOL_A, Total number of containers: 29,440, Successfully audited containers: 231, Failed audited containers: 0'}
        self.assertEqual(b.progress(record,'POOL_A'),[29440,231,0])

    def test_queueing_then_progress_does_not_cancel_immediately(self):
        self.assertEqual(self.execute('benchmark_queue_once',extra=['--processes','10','--minutes','0.004']),0)
        row=self.result()['trials'][0]
        self.assertTrue(row['eligible'])
        self.assertGreaterEqual(row['queueing_observations'],1)
        self.assertGreater(row['first_counter_observed_seconds'],0)
        self.assertGreaterEqual(row['sample_seconds'],0.24)
        self.assertEqual(self.commands().count('CANCEL PROCESS 41'),1)

    def test_queueing_entire_window_stops_with_unknown_counts(self):
        self.assertEqual(self.execute('benchmark_queue_forever'),2)
        row=self.result()['trials'][0]
        self.assertEqual(row['status'],'NO_PROGRESS_COUNTERS_WITHIN_WINDOW')
        self.assertFalse(row['eligible'])
        self.assertIsNone(row['completed_containers'])
        self.assertIsNone(row['containers_per_hour'])
        self.assertIsNone(row['estimated_full_pool_seconds'])
        self.assertGreaterEqual(row['sample_seconds'],0.12)
        self.assertEqual(self.commands().count('CANCEL PROCESS 41'),1)

    def test_transcribed_queueing_is_not_zero_or_arbitrary_status(self):
        path=self.temp/'queueing.txt'
        path.write_text('Process Number: 18,696\nProcess Description: AUDIT CONTAINER\nJob Id:\nProcess Status: Storage pool POOL_A, queueing containers\nParent Process:\n')
        r=list(t.details(str(path),'Process Number'))[0]
        self.assertEqual(t.counter(r['Process Number']),18696)
        self.assertIsNone(b.progress(r,'POOL_A'))
        r['Process Status']='Storage pool POOL_A, unknown state'
        with self.assertRaises(t.ToolError): b.progress(r,'POOL_A')

    def test_cli_expected_error_does_not_print_traceback(self):
        result=subprocess.run([sys.executable,str(Path(t.__file__).resolve()),'benchmark','POOL_A','--minutes','-1'],capture_output=True,text=True)
        self.assertEqual(result.returncode,3)
        self.assertIn('ERROR:',result.stdout)
        self.assertNotIn('Traceback',result.stdout+result.stderr)

    def test_efficiency_and_eta(self):
        r=b.metrics(4000,600,29440,40)
        self.assertEqual(r['containers_per_hour'],24000)
        self.assertEqual(r['containers_per_configured_process'],100)
        self.assertEqual(r['estimated_full_pool_seconds'],4416)

    def test_five_percent_is_duration_not_throughput(self):
        rows=[{'maxprocess':40,'eligible':True,'containers_per_hour':9600},
              {'maxprocess':99,'eligible':True,'containers_per_hour':10000}]
        self.assertEqual(b.recommendation(rows,5)['recommended_maxprocess'],40)
        rows[0]['containers_per_hour']=9500
        self.assertEqual(b.recommendation(rows,5)['recommended_maxprocess'],99)

    def test_repeated_limit_uses_slowest_eligible_trial(self):
        rows=[{'maxprocess':10,'eligible':True,'containers_per_hour':100},
              {'maxprocess':10,'eligible':True,'containers_per_hour':10},
              {'maxprocess':20,'eligible':True,'containers_per_hour':95}]
        self.assertEqual(b.recommendation(rows,5)['recommended_maxprocess'],20)

    def test_aix_private_credentials_permissions_and_cleanup(self):
        root=self.temp/'credentials_test'
        root.mkdir()
        args=t.parser().parse_args(['--credential-mode','auto'])
        with mock.patch.object(t.sys,'platform','aix7'):
            admin=t.Admin(args,str(root),'TESTADMIN',"test-$-quote'`-secret")
        path=Path(admin.credpath)
        self.assertEqual(path.stat().st_mode & 0o777,0o600)
        self.assertEqual(path.parent.stat().st_mode & 0o777,0o700)
        self.assertNotIn('-language=AMENG',admin.client_argv(False))
        admin.close()
        self.assertFalse(path.parent.exists())

    def test_named_file_credential_transport(self):
        self.assertEqual(self.execute(extra=['--credential-mode','file','--processes','10']),0)
