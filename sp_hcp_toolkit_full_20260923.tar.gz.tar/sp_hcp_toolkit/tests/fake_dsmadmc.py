#!/usr/bin/env python3
"""Synthetic protocol fixture. NEVER connects to an IBM server."""
import csv
import json
import os
import re
import time
import sys
from pathlib import Path

scenario = os.environ.get("SP_TEST_SCENARIO", "clean")
state_dir = Path(os.environ["SP_TEST_STATE"])
state_dir.mkdir(exist_ok=True)
state_file = state_dir / "audited"
args = sys.argv[1:]
creds = [s for s in args if s.startswith("-credentialsfile=")]
assert len(creds) == 1
assert not any(s.lower().startswith(("-password=", "-pa=")) for s in args)
cred_path = creds[0].split("=",1)[1]
with open(cred_path) as f:
    assert f.read().splitlines() == ["TESTADMIN", "test-$-quote'`-secret"]
if cred_path.startswith("/proc/self/fd/"):
    assert os.stat(cred_path).st_nlink == 0
else:
    assert os.stat(cred_path).st_mode & 0o777 == 0o600
    assert os.stat(os.path.dirname(cred_path)).st_mode & 0o777 == 0o700
    assert os.stat(cred_path).st_uid == os.getuid()
with open(state_dir / "sessions.jsonl", "a") as f:
    f.write(json.dumps({"pid":os.getpid(),"interactive":"-alwaysprompt" in args}) + "\n")
csv_mode = "-commadelimited" in args


def ok():
    print("ANS8002I Highest return code was 0.")


def empty():
    print("ANR2034E QUERY: No match found using this criteria.")
    print("ANS8002I Highest return code was 11.")
    sys.exit(11)


def rows(values):
    w = csv.writer(sys.stdout, lineterminator="\n")
    w.writerows(values)
    ok()


def record(values):
    for key, value in values:
        print("{:>38}: {}".format(key,value))
    print()


def execute(command):
    audited = state_file.exists()
    with open(state_dir / "commands.jsonl", "a") as f:
        f.write(json.dumps(command) + "\n")
    if command == "QUERY STATUS":
        record([("Server Name","TEST_SERVER"),("Server Version","8"),("Server Release","1"),("Server Level","25.0")])
        ok()
    elif command == "QUERY STGPOOL * FORMAT=DETAILED":
        record([("Storage Pool Name","POOL_A"),("Storage Type","CLOUD"),("Connection Name","CONN_A"),
                ("Cloud Space Allocated (MB)","1,280.00"),("Cloud Space Utilized (MB)","1,024.25")])
        record([("Storage Pool Name","POOL_EMPTY"),("Storage Type","CLOUD"),("Connection Name","CONN_EMPTY"),
                ("Cloud Space Allocated (MB)","0"),("Cloud Space Utilized (MB)","0")])
        if scenario=="many_pools":
            for i in range(30):
                record([("Storage Pool Name","EXTRA_%02d"%i),("Storage Type","CLOUD"),("Connection Name","CONN_A"),("Cloud Space Allocated (MB)","0"),("Cloud Space Utilized (MB)","0")])
        record([("Storage Pool Name","ARCHIVEPOOL"),("Storage Type","DEVCLASS")])
        ok()
    elif command == "QUERY CONNECTION FORMAT=DETAILED":
        record([("Connection Name","CONN_A"),("Cloud Type","S3"),("Cloud URL","https://hcp-new.example.test:443"),
                ("Bucket Name","ns-new")])
        record([("Connection Name","CONN_EMPTY"),("Cloud Type","S3"),("Cloud URL","https://hcp-empty.example.test"),
                ("Bucket Name","ns-empty")])
        ok()
    elif command.startswith("SELECT STGPOOL_NAME,COUNT(*) FROM CONTAINERS"):
        if "POOL_EMPTY" in command:
            empty()
        else:
            n = 3 if scenario=="count_mismatch" else 2
            if scenario=="changed" and audited:
                n = 1
        rows([["POOL_A",n]])
    elif command.startswith("QUERY CONTAINER "):
        if "POOL_EMPTY" in command:
            empty()
        for n in range(1,2 if scenario=="changed" and audited else 3):
            legacy = scenario=="old_target" and n==2
            bucket = "ns-old" if legacy else "ns-new"
            name = "{}/server-guid/{:010d}.dcf".format(bucket,n)
            if scenario=="unknown_target" and n==2:
                name = "opaque-identifier-without-bucket"
            record([("Container",name),("Storage Pool Name","POOL_A"),("Container Type","Cloud"),
                    ("State","Pending" if scenario=="pending" and n==2 else ""),
                    ("Approx. Date Last Written","09/01/2026 10:00:00"),
                    ("Approx. Date Last Audit","09/07/2026 12:00:05" if audited else ""),
                    ("Cloud Type","S3"),("Cloud URL","https://hcp-old.example.test" if legacy else "https://hcp-new.example.test:443"),
                    ("Cloud Object Size (MB)","640"),
                    ("Space Utilized (MB)","" if scenario=="missing_size" and n==2 else "512.125")])
        ok()
    elif command == "QUERY PROCESS":
        if scenario.startswith("benchmark") and (state_dir/"active_parent").exists():
            if scenario=="benchmark_vanish" and (state_dir/"observed").exists():
                (state_dir/"active_parent").unlink()
                print("ANR0944E QUERY PROCESS: No active processes found.")
                print("ANS8001I Return code 11.")
                sys.exit(11)
            queueing = (scenario=="benchmark_queue_forever" or
                        (scenario=="benchmark_queue_once" and not (state_dir/"observed").exists()))
            (state_dir/"observed").write_text("yes")
            if queueing:
                record([("Process Number","41"),("Process Description","AUDIT CONTAINER"),
                        ("Job Id",""),("Process Status","Storage pool POOL_A, queueing containers"),("Parent Process","")])
                ok()
                return
            record([("Process Number","41"),("Process Description","AUDIT CONTAINER"),
                    ("Process Status","Storage pool POOL_A, Total number of containers: 2, Successfully audited containers: 1, Failed audited containers: 0")])
            record([("Process Number","42"),("Process Description","Audit Container (Scan)"),
                    ("Process Status","Container ns-new/server-guid/0000000002.dcf"),("Parent Process","41")])
            ok()
        elif scenario=="already_running":
            record([("Process Number","40"),("Process Description","Audit Container"),("Status","running")])
            ok()
        else:
            # Real 8.1.25 response supplied by the operator, including the
            # interactive command return code (not only the process exit code).
            print("ANR0944E QUERY PROCESS: No active processes found.")
            print("ANS8001I Return code 11.")
            sys.exit(11)
    elif command == "CANCEL PROCESS 41" and scenario.startswith("benchmark"):
        if scenario!="benchmark_cancel_stuck":
            (state_dir/"active_parent").unlink()
        print("ANR0940I Cancel request accepted for process 41.")
        ok()
    elif command.startswith("AUDIT CONTAINER ") and "WAIT=NO" in command and scenario.startswith("benchmark"):
        (state_dir/"active_parent").write_text("41")
        if scenario!="benchmark_no_id":
            print("ANS8003I Process number 41 started.")
        ok()
    elif command == "QUERY DAMAGED POOL_A TYPE=STATUS":
        if scenario=="blank_damage":
            rows([["POOL_A",0,0,""]])
        elif scenario=="empty_damage":
            empty()
        elif scenario=="invalid_damage":
            ok()
        else:
            rows([["POOL_A",0,1 if audited and scenario=="damage" else 0,1 if audited and scenario=="orphan" else 0]])
    elif command == "SELECT CURRENT_TIMESTAMP FROM STATUS":
        rows([["2026-09-07 12:00:10.000000" if audited else "2026-09-07 12:00:00.000000"]])
    elif command.startswith("AUDIT CONTAINER "):
        assert re.fullmatch(r"AUDIT CONTAINER STGPOOL=POOL_A ACTION=SCANALL VALIDATECLOUDEXTENTS=(YES|NO) MAXPROCESS=([1-9]|[1-9][0-9]) WAIT=YES",command)
        state_file.write_text("done")
        if scenario=="disconnect":
            print("ANS1017E Session rejected: TCP/IP connection failure")
            sys.exit(8)
        if scenario=="slow_audit":
            time.sleep(0.35)
        if scenario=="timeout":
            time.sleep(15)
        if scenario!="no_ids":
            print("ANR0984I Process 41 for AUDIT CONTAINER started in the FOREGROUND at 12:00:00.")
            print("ANR4886I AUDIT CONTAINER (Scan) process started for container ns-new/server-guid/0000000001.dcf (process ID 41).")
        if scenario=="canceled":
            print("ANR4890W Audit container process terminated for deletion - process 41 canceled.")
        ok()
    elif command.startswith("SELECT DATE_TIME,MESSAGE FROM ACTLOG "):
        assert "2026-09-07 12:00:00" in command
        assert "2026-09-07 12:00:11" in command
        if scenario=="log_error":
            print("ANR2017E SELECT: Administrator is not authorized")
            sys.exit(3)
        ending_rows = []
        for n in range(1,3):
            if scenario in ("partial","pending") and n==2:
                continue
            pid = 999 if scenario=="foreign_process" else 41
            bad = 1 if scenario=="damage" and n==2 else 0
            orphan = 1 if scenario=="orphan" and n==2 else 0
            msg = ("ANR4891I AUDIT CONTAINER process {} ended for the ns-new/server-guid/{:010d}.dcf container: "
                   "100 data extents inspected, {} data extents marked as damaged, "
                   "0 data extents previously marked as damaged reset to undamaged, and {} data extents marked as orphaned.").format(pid,n,bad,orphan)
            ending_rows.append(["2026-09-07 12:00:05.000000",msg])
        rows(ending_rows)
    else:
        print("ANR2000E Unknown synthetic command")
        sys.exit(3)


def prompt():
    if scenario=="split_prompt":
        for chunk in ("tsm: TES","T_SERVER","> ","\n"):
            sys.stdout.write(chunk)
            sys.stdout.flush()
            time.sleep(0.005)
    else:
        print("tsm: TEST_SERVER> ",flush=True)


if "-alwaysprompt" in args:
    prompt()
    for line in sys.stdin:
        command=line.strip()
        if command=="QUIT":
            sys.exit(0)
        print(command,flush=True)
        try:
            execute(command)
        except SystemExit as exc:
            if scenario=="disconnect" and command.startswith("AUDIT CONTAINER "):
                sys.exit(exc.code)
        prompt()
else:
    execute(args[-1])
