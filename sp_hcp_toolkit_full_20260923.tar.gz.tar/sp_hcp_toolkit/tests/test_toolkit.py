#!/usr/bin/env python3
"""Meaningful offline protocol/scenario tests; no IBM or HCP access."""
import contextlib
import csv
import importlib.util
import io
import json
import os
import pathlib
import shutil
import sqlite3
import tempfile
import unittest
from unittest import mock

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("sp_hcp_audit",HERE.parent/"sp_hcp_audit.py")
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)


class ToolkitTests(unittest.TestCase):
    def setUp(self):
        self.temp = pathlib.Path(tempfile.mkdtemp(prefix="sp_hcp_test_"))
        (HERE/"fake_dsmadmc.py").chmod(0o755)

    def tearDown(self):
        shutil.rmtree(self.temp)

    def run_tool(self,scenario="clean",mode="audit",extra=None):
        root = self.temp/(scenario+"_report")
        args = [mode]
        if mode=="audit":
            args.append("pool_a")
        args += ["--dsmadmc",str(HERE/"fake_dsmadmc.py"),"--out",str(root)]
        args += extra or []
        with mock.patch.dict(os.environ,{"SP_TEST_STATE":str(self.temp/(scenario+"_state")),"SP_TEST_SCENARIO":scenario}), \
             mock.patch("sys.stdin.isatty",return_value=True), \
             mock.patch("builtins.input",return_value="TESTADMIN"), \
             mock.patch.object(tool.getpass,"getpass",return_value="test-$-quote'`-secret"), \
             contextlib.redirect_stdout(io.StringIO()):
            rc = tool.main(args)
        # No password, even with shell metacharacters, in any evidence artifact.
        for f in root.rglob("*"):
            if f.is_file():
                self.assertNotIn(b"test-$-quote'`-secret",f.read_bytes(),str(f))
        return rc,root

    def result(self,root):
        return json.loads((root/"audit_result.json").read_text())

    def readcsv(self,path):
        with path.open() as f:
            return list(csv.DictReader(f))

    def test_clean_audit_has_full_coverage_and_one_pool_command(self):
        rc,root = self.run_tool()
        self.assertEqual(rc,0)
        result = self.result(root)
        self.assertEqual(result["status"],"COMPLETED_CLEAN")
        self.assertEqual(result["correlated_container_completions"],2)
        self.assertFalse(result["namespace_deletion_assessed"])
        commands = [json.loads(s) for s in (self.temp/"clean_state"/"commands.jsonl").read_text().splitlines()]
        audits = [c for c in commands if c.startswith("AUDIT ")]
        self.assertEqual(len(audits),1)
        self.assertIn("STGPOOL=POOL_A",audits[0])
        self.assertIn("VALIDATECLOUDEXTENTS=YES",audits[0])
        self.assertIn("WAIT=YES",audits[0])
        self.assertEqual(len(self.readcsv(root/"audit_container_results.csv")),2)

    def test_old_target_uses_container_endpoint_not_current_connection(self):
        rc,root = self.run_tool("old_target","inventory")
        self.assertEqual(rc,0)
        groups = self.readcsv(root/"before"/"namespaces.csv")
        self.assertEqual({r["namespace_from_container"] for r in groups},{"ns-new","ns-old"})
        old = next(r for r in groups if r["namespace_from_container"]=="ns-old")
        self.assertEqual(old["cloud_url_key"],"https://hcp-old.example.test")
        self.assertIn("ns-old/server-guid/",(root/"before"/old["container_list"]).read_text())
        pools = self.readcsv(root/"before"/"stgpools.csv")
        self.assertEqual(pools[0]["containers_different_target"],"1")
        commands = (self.temp/"old_target_state"/"commands.jsonl").read_text()
        self.assertNotIn('"AUDIT CONTAINER',commands)

    def test_empty_pool_and_rounded_usage_are_explicit(self):
        rc,root = self.run_tool("clean","inventory")
        pools = self.readcsv(root/"before"/"stgpools.csv")
        self.assertEqual(pools[0]["sp_cloud_utilized_MB"],"1024.25")
        self.assertEqual(pools[1]["containers_total"],"0")
        ns = self.readcsv(root/"before"/"namespaces.csv")[0]
        self.assertEqual(ns["sp_utilized_MB_known_sum"],"1024.250")
        configured = self.readcsv(root/"before"/"configured_targets.csv")
        empty = next(c for c in configured if c["namespace"]=="ns-empty")
        self.assertEqual((root/"before"/empty["container_list"]).read_text(),"")

    def test_missing_sizes_are_not_zero_measurements(self):
        rc,root = self.run_tool("missing_size","inventory")
        ns = self.readcsv(root/"before"/"namespaces.csv")[0]
        self.assertEqual(ns["containers_missing_utilized_size"],"1")
        self.assertEqual(ns["sp_utilized_MB_known_sum"],"512.125")

    def test_unresolved_target_does_not_use_connection_fallback(self):
        rc,root = self.run_tool("unknown_target","inventory")
        self.assertEqual(rc,2)
        containers = self.readcsv(root/"before"/"containers.csv")
        unknown = next(c for c in containers if c["name"].startswith("opaque"))
        self.assertEqual(unknown["bucket"],"UNKNOWN")

    def test_count_mismatch_is_review_required(self):
        rc,root = self.run_tool("count_mismatch","inventory")
        self.assertEqual(rc,2)
        self.assertIn("COUNTS_CHANGED_OR_OUTPUT_INCOMPLETE",(root/"REPORT.txt").read_text())

    def test_nonclean_scenarios_never_report_clean(self):
        for scenario in ("partial","damage","orphan","canceled","no_ids","foreign_process","blank_damage","changed","pending","log_error"):
            with self.subTest(scenario=scenario):
                rc,root = self.run_tool(scenario)
                self.assertEqual(rc,2)
                self.assertEqual(self.result(root)["status"],"REVIEW_REQUIRED")
                self.assertTrue(self.result(root)["reasons"])

    def test_metadata_only_audit_is_not_full_validation(self):
        rc,root = self.run_tool(extra=["--validate-cloud-extents","no"])
        self.assertEqual(rc,2)
        self.assertIn("INDIVIDUAL_CLOUD_EXTENTS_NOT_VALIDATED",self.result(root)["reasons"])

    def test_explicit_no_damage_rows_is_different_from_missing_output(self):
        rc,root = self.run_tool("empty_damage")
        self.assertEqual(rc,0)
        with self.assertRaises(tool.ToolError):
            self.run_tool("invalid_damage")
        bad = self.temp/"invalid_damage_report"
        self.assertEqual(json.loads((bad/"run.json").read_text())["status"],"INCOMPLETE_OUTCOME_UNKNOWN")

    def test_existing_audit_prevents_second_submission(self):
        with self.assertRaisesRegex(tool.ToolError,"already active"):
            self.run_tool("already_running")
        commands = (self.temp/"already_running_state"/"commands.jsonl").read_text()
        self.assertNotIn('"AUDIT CONTAINER',commands)

    def test_timeout_is_unknown_not_completion(self):
        with self.assertRaisesRegex(tool.ToolError,"timeout"):
            self.run_tool("timeout",extra=["--audit-timeout","1"])
        root = self.temp/"timeout_report"
        result=json.loads((root/"run.json").read_text())
        self.assertIn("UNKNOWN",result["status"])
        self.assertGreaterEqual(result["audit_elapsed_seconds_observed"],1)
        self.assertTrue((root/"SHA256SUMS.txt").exists())

    def test_disconnect_does_not_replay_audit(self):
        with self.assertRaisesRegex(tool.ToolError,"disconnected"):
            self.run_tool("disconnect")
        commands=[json.loads(x) for x in (self.temp/"disconnect_state"/"commands.jsonl").read_text().splitlines()]
        self.assertEqual(sum(c.startswith("AUDIT CONTAINER ") for c in commands),1)
        self.assertIn("UNKNOWN",json.loads((self.temp/"disconnect_report"/"run.json").read_text())["status"])

    def test_bulk_inventory_uses_two_sessions_and_six_commands_for_many_pools(self):
        rc,root=self.run_tool("many_pools","inventory")
        self.assertEqual(rc,0)
        profile=json.loads((root/"client_profile.json").read_text())
        self.assertEqual(profile["client_process_starts"],2)
        self.assertEqual(profile["server_commands_submitted"],6)
        self.assertEqual(len(self.readcsv(root/"before"/"stgpools.csv")),32)
        commands=[json.loads(x) for x in (self.temp/"many_pools_state"/"commands.jsonl").read_text().splitlines()]
        self.assertEqual(sum(c.startswith("QUERY CONTAINER ") for c in commands),1)
        self.assertEqual(sum("GROUP BY STGPOOL_NAME" in c for c in commands),2)

    def test_split_prompts_and_command_echo_are_framed(self):
        rc,root=self.run_tool("split_prompt","inventory")
        self.assertEqual(rc,0)

    def test_audit_timing_and_configured_parallelism(self):
        rc,root=self.run_tool("slow_audit",extra=["--maxprocess","16"])
        result=self.result(root)
        self.assertEqual(rc,0)
        self.assertEqual(result["configured_maxprocess"],16)
        self.assertGreaterEqual(result["audit_elapsed_seconds"],0.35)
        self.assertLess(result["audit_elapsed_seconds"],result["phase_timings_seconds"]["workflow_to_report"])
        self.assertEqual(result["client_profile"]["client_process_starts"],3)
        self.assertEqual(result["extents_inspected"],200)
        self.assertEqual(len(result["scope_signature_sha256"]),64)
        self.assertEqual(len(self.readcsv(root/"audit_performance.csv")),1)
        self.assertIn("Audit duration:",(root/"REPORT.txt").read_text())

    def test_batch_compatibility_retains_bulk_queries(self):
        rc,root=self.run_tool("clean","inventory",["--client-mode","batch"])
        self.assertEqual(rc,0)
        profile=json.loads((root/"client_profile.json").read_text())
        self.assertEqual(profile["client_process_starts"],6)
        self.assertEqual(profile["server_commands_submitted"],6)

    def test_candidate_crosscheck_distinguishes_unused_and_referenced(self):
        candidate = self.temp/"candidates.csv"
        candidate.write_text("namespace,cloud_url\nns-new,https://hcp-new.example.test:443\nns-gone,https://gone.example.test\nns-new,https://alias.example.test\n")
        rc,root = self.run_tool(mode="inventory",extra=["--candidates",str(candidate)])
        rows = self.readcsv(root/"candidate_namespaces.csv")
        self.assertEqual(rows[0]["observation"],"REFERENCE_OR_CONFIGURATION_PRESENT")
        self.assertEqual(rows[1]["observation"],"NO_REFERENCE_FOUND_IN_THIS_INSTANCE_SCOPE")
        self.assertIn("INCONCLUSIVE",rows[2]["observation"])
        self.assertEqual({r["deletion_assessment"] for r in rows},{"NOT_DETERMINED"})

    def test_parser_wraps_long_names_urls_and_retains_nonempty_duplicate_field(self):
        path = self.temp/"wrapped.txt"
        path.write_text("Container: ns/prefix/"+"x"*90+"\n       tail.dcf\nStorage Pool Name: POOL_A\nCloud URL: https://hcp.example.test/\n     endpoint\nANS8002I Highest return code was 0.\n")
        c = list(tool.details(str(path),"Container"))[0]
        self.assertTrue(c["Container"].endswith("xtail.dcf"))
        self.assertEqual(c["Cloud URL"],"https://hcp.example.test/endpoint")
        path.write_text("Container: ns/prefix/file.dcf\nCloud URL: https://long.\n     host.example.test:443/api\n")
        self.assertEqual(list(tool.details(str(path),"Container"))[0]["Cloud URL"],"https://long.host.example.test:443/api")
        path.write_text("Storage Pool Name: POOL_A\nConnection Name: CONN_A\nConnection Name: \n")
        self.assertEqual(list(tool.details(str(path),"Storage Pool Name"))[0]["Connection Name"],"CONN_A")

    def test_shell_injection_and_wildcards_rejected(self):
        for value in ("*","POOL;DELETE STGPOOL X","$(id)","A\nB","A'", "A"*31):
            with self.assertRaises(tool.ToolError):
                tool.pool_arg(value)

    def test_case_sensitive_bucket_and_url_path_preserved(self):
        self.assertEqual(tool.url_key("HTTPS://HCP.EXAMPLE.TEST/CasePath/"),"https://hcp.example.test/CasePath")
        self.assertEqual(tool.bucket_from_container("CaseBucket/server/file.dcf"),"CaseBucket")
        self.assertNotEqual(tool.url_key("https://a/x"),tool.url_key("https://a/X"))

    def test_real_no_process_response_is_accepted_only_for_process_query(self):
        path = self.temp/"no_process.txt"
        path.write_text("ANR0944E QUERY PROCESS: No active processes found.\nANS8001I Return code 11.\n")
        for rc in (None,11):
            result = tool.command_diagnostics(str(path),rc,True,"QUERY PROCESS")
            self.assertTrue(result["ok"])
            self.assertTrue(result["explicit_no_match"])
            self.assertEqual(result["command_return_codes"],[11])
        self.assertFalse(tool.command_diagnostics(str(path),None,False,"QUERY PROCESS")["ok"])
        self.assertFalse(tool.command_diagnostics(str(path),None,True,"AUDIT CONTAINER STGPOOL=POOL_A")["ok"])
        path.write_text(path.read_text()+"ANR2017E Administrator not authorized.\n")
        self.assertFalse(tool.command_diagnostics(str(path),None,True,"QUERY PROCESS")["ok"])

    def test_interactive_nonzero_return_code_is_not_ignored(self):
        path = self.temp/"return_code.txt"
        for value in (3,11,9999):
            path.write_text("ANS8001I Return code {}.\n".format(value))
            self.assertFalse(tool.command_diagnostics(str(path),None,True,"QUERY PROCESS")["ok"])
        path.write_text("ANS8001I Return code 0.\n")
        self.assertTrue(tool.command_diagnostics(str(path),None)["ok"])

    def test_connection_identity_does_not_contaminate_bucket(self):
        path = self.temp/"connection.txt"
        path.write_text("Connection Name: CONN_A\nCloud Type: S3\nBucket Name: ns-new\nIdentity: SYNTHETIC_ACCESS_ID\nCloud URL: https://hcp.example.test\n")
        record = list(tool.details(str(path),"Connection Name"))[0]
        self.assertEqual(record["Bucket Name"],"ns-new")
        self.assertEqual(record["Identity"],"SYNTHETIC_ACCESS_ID")
        self.assertEqual(record["Cloud URL"],"https://hcp.example.test")

    def test_batch_audit_accepts_real_no_process_response(self):
        rc,root = self.run_tool(extra=["--client-mode","batch"])
        self.assertEqual(rc,0)
        self.assertEqual(self.result(root)["status"],"COMPLETED_CLEAN")

    def test_unknown_numeric_format_rejected(self):
        for value in ("1,23","abc","1.2.3","NaN","-1"):
            with self.assertRaises(tool.ToolError):
                tool.numeric(value)
        for value in ("", "0.5", "1.1"):
            with self.assertRaises(tool.ToolError):
                tool.counter(value)


if __name__=="__main__":
    unittest.main(verbosity=2)
