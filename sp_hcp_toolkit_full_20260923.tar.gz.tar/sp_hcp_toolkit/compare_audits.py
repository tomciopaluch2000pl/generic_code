#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Compare existing audit_result.json files locally. No dsmadmc connection.

Reading guide: load_result validates each saved result; comparison_rows checks
whether it is comparable with the first run; write_rows emits the resulting CSV.
This tool never runs additional audits or chooses a process setting for you.
"""
from __future__ import print_function, unicode_literals
import argparse
import csv
import io
import json
import math
import os
import sys

PY2 = sys.version_info[0]==2
TEXT = type(u"")
HEADERS = ["server","storage_pool","maxprocess","status","duration_hms","elapsed_seconds",
           "completed_containers","containers_per_minute","inspected_extents","extents_per_second",
           "speedup_vs_first_run","duration_reduction_pct","comparison_notes","source"]


def load_result(path):
    """Accept a run directory or JSON file and require the v1.1 timing evidence."""
    if os.path.isdir(path):
        path = os.path.join(path,"audit_result.json")
    with io.open(path,encoding="utf-8") as f:
        data = json.load(f)
    required = ["server_name","pool","configured_maxprocess","status","audit_duration_hms",
                "audit_elapsed_seconds","scope_signature_sha256","validate_cloud_extents",
                "audit_timing_basis","correlated_container_completions","extents_inspected"]
    missing = [k for k in required if k not in data]
    if missing:
        raise ValueError("Missing v1.1 fields in {}: {}".format(path,", ".join(missing)))
    seconds = float(data["audit_elapsed_seconds"])
    if math.isnan(seconds) or math.isinf(seconds) or seconds<=0:
        raise ValueError("A positive finite audit duration is required: " + path)
    data["audit_elapsed_seconds"] = seconds
    data["source"] = os.path.abspath(path)
    return data


def comparison_rows(results):
    """Yield one row per run, suppressing speedup for mismatched evidence.

    The first argument is always the baseline, not the fastest result. Matching
    inventory/settings cannot eliminate effects of cache or competing workload.
    """
    baseline = results[0]
    for item in results:
        notes = []
        checks = [("server_name","DIFFERENT_SERVER"),("pool","DIFFERENT_POOL"),
                  ("scope_signature_sha256","DIFFERENT_INVENTORY"),
                  ("validate_cloud_extents","DIFFERENT_VALIDATION"),
                  ("audit_timing_basis","DIFFERENT_TIMING_BASIS")]
        for field,note in checks:
            if item[field]!=baseline[field]:
                notes.append(note)
        if item["status"]!="COMPLETED_CLEAN" or baseline["status"]!="COMPLETED_CLEAN":
            notes.append("AUDIT_NOT_CLEAN")
        if item.get("is_fictional_example") or baseline.get("is_fictional_example"):
            notes.append("FICTIONAL_DATA")
        blocked = any(n!="FICTIONAL_DATA" for n in notes)
        # Allow calculations in clearly labelled training examples, but do not
        # calculate a success comparison when scope or audit quality differs.
        speedup = None if blocked else round(baseline["audit_elapsed_seconds"]/item["audit_elapsed_seconds"],4)
        reduction = None if blocked else round(100.0*(1-item["audit_elapsed_seconds"]/baseline["audit_elapsed_seconds"]),3)
        yield [item["server_name"],item["pool"],item["configured_maxprocess"],item["status"],
               item["audit_duration_hms"],item["audit_elapsed_seconds"],item["correlated_container_completions"],
               item.get("completed_containers_per_minute"),item["extents_inspected"],
               item.get("inspected_extents_per_second"),speedup,reduction,
               ";".join(notes) or "Same recorded inventory/settings; external load and cache effects are not measured",
               item["source"]]


def write_rows(stream,rows):
    """Write Python 2/3 CSV and neutralize spreadsheet formulas in text fields."""
    writer = csv.writer(stream,lineterminator="\n")
    for row in rows:
        cells = []
        for value in row:
            cell = "" if value is None else TEXT(value)
            if isinstance(value,TEXT) and cell.startswith(("=","+","-","@")):
                cell = "'"+cell
            cells.append(cell.encode("utf-8") if PY2 else cell)
        writer.writerow(cells)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs",nargs="+",help="Audit directories or audit_result.json paths, first run is baseline")
    parser.add_argument("--out",help="Create a new CSV; defaults to standard output")
    args = parser.parse_args(argv)
    results = [load_result(p) for p in args.runs]
    if args.out:
        # Exclusive creation protects a previous comparison from overwrite.
        fd = os.open(args.out,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        stream = os.fdopen(fd,"wb") if PY2 else io.open(fd,"w",encoding="utf-8",newline="")
    else:
        stream = sys.stdout
    try:
        write_rows(stream,[HEADERS])
        write_rows(stream,comparison_rows(results))
    finally:
        if args.out:
            stream.close()
    return 0


if __name__=="__main__":
    try:
        sys.exit(main())
    except (ValueError,IOError,OSError) as exc:
        print("ERROR: " + TEXT(exc),file=sys.stderr)
        sys.exit(3)
