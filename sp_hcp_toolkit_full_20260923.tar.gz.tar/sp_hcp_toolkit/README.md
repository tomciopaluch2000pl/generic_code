# IBM Storage Protect / HCP Audit Toolkit 1.2.0

English operations handover for an IBM Storage Protect 8.1.25 instance using HCP through S3 cloud-container storage pools. The toolkit collects evidence through `dsmadmc` and audits one explicitly selected storage pool.

## Version 1.2.0

Adds time-bounded `benchmark` trials, throughput/ETA reports, and selection of the smallest tested process limit within a chosen time penalty. Adds a portable credential-file transport for AIX 7.3. Preserves the operator's corrections: `QUERY CONNECTION FORMAT=DETAILED` has no wildcard, and `-language=AMENG` is no longer passed. English client output remains required for parsing; numeric/date options and the C locale remain explicit.

Install the whole package: `benchmark_audits.py` must be beside `sp_hcp_audit.py`. Existing `inventory` and full `audit` commands remain available. See [BENCHMARK.md](BENCHMARK.md) for timed trials, formulas, an example, and AIX setup.

## Version 1.1.1 fixes

- Accept the real `ANR0944E QUERY PROCESS: No active processes found.` response with `ANS8001I Return code 11` as an empty process list. The exemption is restricted to `QUERY PROCESS` with empty results allowed; other errors and unexplained nonzero codes still fail.
- Check interactive `ANS8001I` command return codes, in addition to batch exit codes and `ANS8002I` summaries.
- Parse the connection's `Identity` label separately, preventing it from being appended to `Bucket Name`. Regenerate inventories made with 1.1.0 if their configured namespace contains `Identity:`; those configuration comparisons are unreliable.

These fixes were reproduced using sanitized fixtures transcribed from an operator's IBM 8.1.25 output. A complete real-server audit has not yet been validated. Existing example reports illustrate the 1.1 output format and retain their original version label.

## Quick start

Run the script from the same OS account and environment in which `dsmadmc` already connects to the intended instance:

```bash
python sp_hcp_audit.py
```

The default `inventory` mode prompts only for the administrator ID and password. It uses the existing client configuration and creates a new timestamped output directory.

Audit a specific pool with a configurable process limit:

```bash
python sp_hcp_audit.py audit HCP_POOL_A --maxprocess 16
```

Optional connection and output settings:

```bash
python sp_hcp_audit.py inventory \
  --server SP_INSTANCE_STANZA \
  --optfile /path/to/dsm.opt \
  --dsmadmc /opt/tivoli/tsm/client/ba/bin/dsmadmc \
  --out ./hcp_inventory_20260907
```

The `--server` value identifies an existing stanza in `dsm.sys`. Output directories must be new; existing directories are never overwritten. Use `python3` in place of `python` if appropriate. The command language, help, messages, documentation and report labels are English. The former Polish command alias has been removed; use `audit`.

## Requirements

- Linux (including RHEL 7.9) or AIX 7.3. AIX portability was implemented and tested with simulated platform selection; a native AIX integration run remains necessary.
- Python 2.7 or Python 3.6+ with the standard library, including SQLite. No `pip`, S3 SDK, `expect` or additional Python packages are required by the operational scripts.
- A working administrative client supporting `-credentialsfile`; this option is documented for client 8.1.25. Server and client versions are separate prerequisites.
- Existing server connectivity and TLS configuration. This toolkit does not configure TLS or change client options files.
- An administrator without MFA. IBM does not support `-credentialsfile` for MFA administrators.
- Access to the queries used by the toolkit. Auditing requires system privilege or unrestricted storage privilege.
- Sufficient local disk space for container listings, CSV exports, the SQLite working database and activity-log evidence. Large listings are streamed to disk.

The operational scripts target the above Python syntax levels. Runtime tests were performed with Python 3.12 and a synthetic client, not with a real IBM server or a Python 2 interpreter.

## How version 1.1 reduces client overhead

Version 1.0 started a new authenticated `dsmadmc` process for every command. Version 1.1 reuses two administrative clients: one for labelled LIST responses and one for CSV responses. Commands within each session run sequentially.

A complete inventory normally uses **two client process starts and six server commands**, independent of the number of cloud pools:

1. `QUERY STATUS`
2. `QUERY STGPOOL * FORMAT=DETAILED`
3. `QUERY CONNECTION FORMAT=DETAILED`
4. `SELECT STGPOOL_NAME,COUNT(*) FROM CONTAINERS GROUP BY STGPOOL_NAME`
5. `QUERY CONTAINER * TYPE=ANY FORMAT=DETAILED`
6. The same grouped count query after the listing.

If the scope contains one pool, both the listing and count queries are restricted to it. For an inventory with several cloud pools, the bulk container listing is filtered locally to the configured cloud pools. Containers in known non-cloud pools are excluded. On a mixed installation this still reads the server-wide container listing; the original use case is an instance with cloud pools only.

There are no per-container server queries. Grouping by namespace, file creation, size aggregation and cross-checking run locally. Counts are compared before and after the listing to detect incomplete or changing output. This is not a transactionally consistent snapshot.

An audit normally uses **three client starts**: the LIST client remains active, while the unused CSV client is deliberately closed before the long audit and reopened afterwards. This avoids leaving the CSV client idle for the entire audit. Additional starts are possible if a client has already exited before the next command is submitted. An in-flight audit is never automatically replayed after a disconnect.

`client_profile.json` records actual client starts, submitted commands and session startup timings. `commands.json` records individual command durations. A client process start and a server command are different measurements.

The reusable session uses IBM's `-alwaysprompt` and `-newlineafterprompt` options. An unrecognized or missing final prompt is an incomplete response, not a success. If the installed client does not work with this protocol, explicitly select the documented batch compatibility mode:

```bash
python sp_hcp_audit.py inventory --client-mode batch
```

Batch mode still uses the bulk queries, but starts a client for each command. It is not selected automatically after a failed audit.

## Inventory files and mapping

| File | Purpose |
|---|---|
| `REPORT.txt` | Server identity, scope, inventory/audit result, timings and interpretation |
| `before/stgpools.csv` | Current pool-to-connection mapping and SP-reported pool usage |
| `before/connections.csv` | All connections, including those without an assigned cloud pool |
| `before/containers.csv` | Container identities, actual endpoints, state, type and sizes |
| `before/namespaces.csv` | Usage and container counts grouped by observed bucket + Cloud URL |
| `before/namespace_lists/*.txt` | One complete container identifier per line, without headers |
| `before/configured_targets.csv` | Current connection targets, including targets with no containers in scope |
| `before/snapshot.json` | Scope and before/after count checks |
| `audit_commands.txt` | One generated audit command per cloud pool |
| `audit_commands/POOL.mac` | One pool's pre-audit damage query, audit and post-audit damage query |
| `configuration.json` | Initial configuration and server identity |
| `commands.json`, `client_profile.json` | Command evidence and measured client overhead |
| `timings.csv` | Phase durations in seconds and HH:MM:SS |
| `raw/` | Preserved command responses and session startup output |
| `run.json`, `evidence.sqlite` | Run state and local working database |
| `SHA256SUMS.txt` | Integrity checksums for the captured files |

The mapping deliberately preserves two distinct observations:

- **Current configuration:** storage pool → connection → configured bucket and Cloud URL.
- **Container references:** the container's own Cloud URL and the bucket extracted from its S3 identifier, such as `bucket/server-prefix/file.dcf`.

Container lists use the latter. A historical reference must not be replaced by the current connection's target. Differences are marked `DIFFERS_FROM_CURRENT_CONNECTION` in the detailed export. If the bucket cannot be determined from the identifier, it remains `UNKNOWN` and the inventory requires review.

Each list filename contains a sanitized namespace, sanitized Cloud URL and a short SHA-256 suffix to avoid collisions. Original URLs remain in the CSV. The list preserves the full container name, including the bucket and prefix.

Local staging containers in cloud pools are included in the full inventory and counts, but not in HCP namespace lists. Pending containers remain visible. A cloud pool does not imply that every container is already in HCP.

## Audit operation

The command for the example above is:

```text
AUDIT CONTAINER STGPOOL=HCP_POOL_A ACTION=SCANALL VALIDATECLOUDEXTENTS=YES MAXPROCESS=16 WAIT=YES
```

One command covers the selected pool. IBM manages its container processing internally.

`SCANALL` can mark or reset damaged extents and mark orphaned extents in the SP database. Audit mode is therefore not read-only. `VALIDATECLOUDEXTENTS=YES` adds individual extent checks to consolidated metadata validation and can increase cloud reads and runtime. It is not described here as proof that every application byte has been restored. `WAIT=YES` keeps the command in the foreground until it finishes. There are no audit-date filters that restrict the scan to previously audited containers.

The toolkit does not submit removal, repair, connection-update or namespace-rename commands. It does not use `REMOVEDAMAGED`, `MARKDAMAGED` or `FORCEORPHANDBDEL`.

The supported `MAXPROCESS` input range is **1–99**. This is a maximum process setting, not a promise that all those processes are active or that a larger value is faster. The default remains 4 as a baseline; select a higher value explicitly. Measure representative runs and review server CPU, I/O, memory and HCP response behavior before increasing further. There is no universal recommended maximum for this installation, and the script does not automatically run a tuning sequence.

An optional metadata-only variant is available:

```bash
python sp_hcp_audit.py audit HCP_POOL_A --validate-cloud-extents no
```

That result records the weaker validation setting and cannot receive `COMPLETED_CLEAN`.

Keep long audits in a durable terminal session such as an already approved `screen` or `tmux` session. The script prints elapsed time while waiting and reports the audit duration immediately after the audit command returns, before collecting final evidence.

Defaults: 60 seconds for the initial prompt, 3600 seconds per query and no audit timeout. Use `--connect-timeout`, `--query-timeout` or `--audit-timeout` to change them. A query/audit timeout of 0 means unlimited. An observed duration after an interruption is not a completed audit duration.

## Audit result and time measurements

Audit runs contain both `before/` and `after/` inventories, plus:

| File | Purpose |
|---|---|
| `audit_result.json` | Result, reasons, timestamps, process setting, duration, rates and scope signature |
| `audit_performance.csv` | One row suitable for performance comparisons |
| `audit_container_results.csv` | Correlated ANR4891I results and per-container extent counters |
| `audit_containers_without_completion.csv` | Initial containers without a recognized completion for this audit |
| `audit_inventory_changes.csv` | Appeared/disappeared containers and target/type/last-written changes |
| `configuration_after.json` | Final configuration |
| `raw/*audit_activity_log.txt` | Activity-log rows from the server-time observation window |

`QUERY DAMAGED POOL TYPE=STATUS` is collected before and after the audit. `TYPE=INVENTORY` serves a different purpose: information about damaged files.

Performance fields have precise meanings:

- **Audit duration:** client-observed elapsed time from submitting the audit command to receiving its final prompt in persistent mode. It excludes login, inventories and report generation. It is not a server CPU-time measurement.
- **Batch timing:** includes the audit client's startup/login, and is labelled `batch_client_wall_time_including_login`. Do not directly compare it with persistent-session timing.
- **Server observation window:** server clock readings bracketing the audit. It includes control-query and reconnect overhead and is not substituted for the measured audit duration.
- **Phase durations:** initial configuration, initial inventory, pre-audit checks, audit, post-audit collection and evidence analysis. `workflow_to_report` is an overall elapsed observation and is not another phase to add to the others. It excludes final report serialization and the final checksum pass.
- **Containers/minute and extents/second:** rates derived from correlated completion records and audit elapsed time. They do not measure bytes read, network throughput or actual concurrent worker count. In a partial run, coverage is incomplete and the status remains visible.
- **Scope signature:** a SHA-256 fingerprint of recorded container identities, types, endpoints, reported utilized sizes and last-written values. It helps detect comparisons of different recorded inventories; it is not a content hash of the stored payloads.

`COMPLETED_CLEAN` requires a successful command response, complete correlated container endings, zero final damaged/orphaned counters and successful scope/configuration checks. A prompt or client exit code alone does not prove success. Missing evidence, changed inventory, unknown counters, metadata-only validation or findings produce `REVIEW_REQUIRED`.

A disconnect, timeout or failure to finish collecting evidence in full `audit` mode produces `INCOMPLETE_OUTCOME_UNKNOWN`. Already submitted server work may still run. Inspect `QUERY PROCESS` and the activity log before resubmitting it. Full `audit` mode stops its own client when necessary but does not send `CANCEL PROCESS`. The separate `benchmark` mode intentionally cancels its verified parent process at the end of each timed trial and checks that all audit processes have stopped.

Exit codes: 0 for a collected inventory or clean audit; 2 for review required; 3 for an execution error; 130 for interruption. These codes are not namespace-deletion decisions.

## Comparing process settings

After separately collecting audit runs, compare them locally without another login:

```bash
python compare_audits.py ./run_mp8 ./run_mp16 ./run_mp24 --out comparison.csv
```

Each argument may be an audit directory or an `audit_result.json` file. The first run is the baseline. The output file must be new; omit `--out` to write CSV to standard output.

The comparison includes MAXPROCESS, duration, completion rates and speedup versus the baseline. It suppresses the speedup calculation for different servers, pools, recorded inventories, validation settings, timing bases or non-clean results. Matching these fields still does not control concurrent workload, cache state or HCP load; interpret the measurements in their operational context. Fictional example rows carry `FICTIONAL_DATA`.

## Usage and namespace-deletion evidence

Pool reports preserve `Cloud Space Allocated (MB)` and `Cloud Space Utilized (MB)` reported by SP. Namespace reports aggregate observed container values. The underlying `QUERY` values can be rounded; missing sizes are counted separately and are not treated as measured zeros. Columns named `known_sum` sum only known values. TiB columns explicitly assume binary MB and divide by 1,048,576; retain the original MB when reconciling with other reporting systems.

This is usage visible to the queried SP instance. It is not the complete physical or billable usage of HCP, a list of every HCP object, or an automatic measurement of DR copies. HCP overhead, versions, unrelated applications and other SP instances require separate data sources.

To check named old targets, prepare a CSV with exactly these columns:

```csv
namespace,cloud_url
old-namespace-example,https://hcp-old.example.test
```

Then run a full inventory:

```bash
python sp_hcp_audit.py inventory --candidates candidates.csv
```

`candidate_namespaces.csv` shows exact references, matching connection definitions and same-bucket references under other URLs. `NO_REFERENCE_FOUND_IN_THIS_INSTANCE_SCOPE` means only that no reference was found in this captured instance/scope. Unknown mappings or possible endpoint aliases are not silently treated as absence.

When candidates are supplied, `REPORT.txt` also includes their reference-check results, so they can be presented alongside the audit report. Preserve the full output directories as supporting evidence rather than copying only the success label.

For a migration/federation change, combine this evidence with reconciliation of the expected source/target data and an application-level CMOD/SP retrieval test. Review source and DR instances, DB backup usage and other consumers. A clean audit of retained pools cannot by itself establish migration completeness or prove that old namespaces are unused elsewhere. The toolkit preserves unassigned connections but does not analyze the entire DB-backup lifecycle. DNS aliases and HCP tenant/endpoint identity require explicit reconciliation outside this script.

Integrity checks can be run from an output directory:

```bash
sha256sum -c SHA256SUMS.txt
```

These checksums verify captured-file integrity, not an independently certified timestamp or signature.

## Credentials and validation

The password is entered without terminal echo. It is not accepted through CLI arguments or environment variables and is not written to reports. On Linux, `-credentialsfile` reads an immediately unlinked temporary file through `/proc/self/fd/N`; `/dev/shm` is preferred. On AIX, it reads a mode-0600 file in a mode-0700 temporary directory, removed after clients close. `--credential-mode file` explicitly selects that portable transport on Linux too. SIGKILL or power loss can leave the named file behind; its private directory is named `sp_hcp_credentials_*` beneath the OS temporary directory. Remove such stale directories owned by the account only after confirming no toolkit run is using them. Output directories have owner-only access.

There is no insecure password-in-argv fallback. A client without the required option fails the run. Unexpected output is treated as incomplete or requiring review, rather than guessed.

Offline validation uses the synthetic client in `tests/`. It covers session reuse, command echo, split prompts, bulk counts, timing, selected parallelism, lost sessions without replay, failed/incomplete audits, target changes, missing values, credential handling and comparison eligibility.

```bash
python3 -m unittest discover -s tests -v
```

The tests do not connect to SP or HCP. First run `inventory` against the real client to validate its formatting and reusable-session behavior before using audit mode.

See `EXAMPLE_OUTPUT.md` and `examples/` for explicitly fictional output. Their durations and rates demonstrate formatting, not measured IBM/HCP performance.

## Maintainer's guide

Read `main()` first to follow the workflow. The module introduction and comments explain the reasons behind the evidence checks, session reuse, timing boundaries and failure handling.

| Code area | Responsibility |
|---|---|
| `details`, `csv_rows`, `command_diagnostics` | Parse forced English responses and distinguish missing output from explicit no matches |
| `AdminSession`, `Admin` | Credentials, persistent clients, response boundaries, raw logs and command timing |
| `configuration`, `capture_snapshot` | Bulk server queries and before/after count checks |
| `new_database`, `export_snapshot` | Local SQLite storage, grouping, usage totals and namespace files |
| `finish_audit`, `consume_audit_messages` | Correlate process IDs and container endings; decide whether evidence is complete and clean |
| `candidate_report`, `report_text` | Present observed references, findings and the limits of the conclusion |
| `manifest` | Hash completed output files |
| `compare_audits.py` | Compare saved results locally; no server connection |

Do not replace unknown measurements with zero, remove completion correlation, or retry an interrupted audit automatically. These would change the meaning of the report. Tests and the fictional client are training/development utilities; the three operational Python files target Python 2.7 compatibility.

## IBM references

- [Cloud AUDIT CONTAINER, 8.1.25](https://www.ibm.com/docs/en/storage-protect/8.1.25?topic=commands-cloud-container-audit)
- [QUERY CONTAINER, 8.1.25](https://www.ibm.com/docs/en/storage-protect/8.1.25?topic=commands-query-container-display-container-information)
- [QUERY STGPOOL, 8.1.25](https://www.ibm.com/docs/en/storage-protect/8.1.25?topic=commands-query-stgpool-query-storage-pools)
- [QUERY CONNECTION, 8.1.25](https://www.ibm.com/docs/en/storage-protect/8.1.25?topic=commands-query-connection-query-cloud-connection)
- [Administrative client options, 8.1.25](https://www.ibm.com/docs/en/storage-protect/8.1.25?topic=client-administrative-options)
- [QUERY DAMAGED, available IBM documentation](https://www.ibm.com/docs/en/storage-protect/8.2.1?topic=qc-query-damaged-query-damaged-in-directory-container-cloud-container-storage-pool)
- [ANR messages including ANR4891I, available IBM documentation](https://www.ibm.com/docs/en/storage-protect/8.2.1?topic=list-anr-messages-04001-06000)

The command pages for audit, containers, pools, connections and client options were checked in 8.1.25 documentation during initial development. QUERY DAMAGED and ANR message descriptions were checked in the available IBM documentation linked above when their 8.1.25 pages could not be retrieved. A live integration test remains necessary for the installed client/server build.
