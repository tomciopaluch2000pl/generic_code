# Timed audit benchmark and AIX handover — version 1.2.0

## Benchmark module hotfix 1.2.1

The main entry point remains 1.2.0; only `benchmark_audits.py` needs replacement.
The real IBM status `Storage pool POOL, queueing containers` is now recognized
as preparation without counters. The script waits within the requested sample
window, recording preparation observations separately. Preparation is included
in elapsed time and therefore in the end-to-end throughput estimate.

If the entire window passes without counters, the owned process is cancelled,
the result is `NO_PROGRESS_COUNTERS_WITHIN_WINDOW`, and counts/rates/ETA remain
unknown. No later process setting is started. An arbitrary unrecognized status
still fails instead of being interpreted as preparation. The first observed
counter time is an observation boundary, not the exact queueing duration.

`benchmark_result.json` and `REPORT.txt` identify module version 1.2.1. Expected
benchmark errors now use the entry point's error handler without a traceback.

```bash
python3 -c "import benchmark_audits; print(benchmark_audits.BENCHMARK_VERSION)"
```

## Run short samples

Use the normal entry point with the new `benchmark` mode:

```bash
python3 sp_hcp_audit.py benchmark ODSP_H_TE2_ODLAHU01 \
  --minutes 10 --processes 10,20,40 --out ./benchmark_10m
```

It prompts once for the administrator ID and password. One initial inventory covers the selected pool; it is not repeated for every process setting. Progress queries reuse the administrative client. No per-container audit commands are submitted.

To explicitly test the six limits discussed:

```bash
python3 sp_hcp_audit.py benchmark ODSP_H_TE2_ODLAHU01 \
  --minutes 10 --processes 10,20,40,60,80,99 \
  --tolerance-percent 5 --out ./benchmark_six_limits
```

Use `--minutes 20` for twenty-minute samples. Six ten-minute samples take approximately one hour **plus** initial inventory, query delays, cancellation/worker settling and cooldowns. This is a requested observation window, not a hard server execution deadline. Each control query has a 60-second timeout; an unresponsive server can prevent timely cancellation.

The default process list is `10,20,40`. Higher limits are executed only when explicitly included. There is no assumption that 99 is faster, and no claim that a short run at 99 cannot overload the server. This tool does not measure DB CPU, memory or HCP latency; the recommendation is based on throughput, not a resource-safety determination. Existing audits must finish before a trial can start. The script rejects an active audit rather than cancelling it.

## Trial lifecycle

1. Check that there are no active container audits.
2. Submit one pool-wide `AUDIT CONTAINER ... ACTION=SCANALL VALIDATECLOUDEXTENTS=YES MAXPROCESS=N WAIT=NO`.
3. Record the parent process ID returned by `ANS8003I`. Never guess an ID from a global process list.
4. Poll `QUERY PROCESS`, normally every 30 seconds, using the existing LIST client. Read the parent's total, successful and failed container counters.
5. At the requested duration, retain the last observed counters and their elapsed time. Recheck the parent ID, description and pool, then issue `CANCEL PROCESS parent_id`.
6. Wait until all visible container audits have disappeared. A cancellation acknowledgement alone is insufficient. If workers remain or an unrelated audit appears, wait up to the settling limit and stop the sequence without cancelling other processes.
7. Check damage counters and the pool container count. Save the trial and pause before the next setting.

`--poll-seconds 30`, `--settle-seconds 300` and `--cooldown-seconds 30` control these intervals. Polling is sequential; it does not launch a client per read. The rate timestamp belongs to the progress observation, before cancellation. Containers that finish during cancellation are excluded from the measured count and rate. A process that disappears before a final counter can be observed is marked `ENDED_WITHOUT_FINAL_COUNTERS`, not assumed successful.

If a trial records failures, unknown damage counters, a changed total, or fewer than `--min-containers 100` successful containers, it is excluded from selection and the sequence stops for review. Lower `--min-containers` only when intentionally accepting a small, less representative sample. If the parent reports all containers completed while still visible, the sample can be used for performance calculations; this does not turn the benchmark into a full integrity audit.

On an ordinary exception or handled interruption, the script attempts to stop only the parent it has identified and verified. If submission acknowledgement is missing, the ID is unknown and no guessed cancellation is issued. On connection loss, SIGKILL or server failure, stopping cannot be guaranteed. `benchmark_result.json` records the active parent ID when known. Inspect `QUERY PROCESS` before another run.

## Statistics and selection rule

For `C` successfully audited containers observed after `T` seconds, pool total `N`, and configured limit `P`:

- Containers/hour = `C / T * 3600`.
- Containers per configured process over the sample = `C / P`.
- Containers/hour per configured process = `(C / T * 3600) / P`.
- Estimated whole-pool time = `N / (C / T)`.
- Estimated remaining time from that sample counter = `(N - C) / (C / T)`.

The per-process figures are **nominal ratios using MAXPROCESS**, not measured work performed by each worker. The observations record linked visible worker counts when the client exposes `Parent Process`; an unavailable relationship is left unknown. No actual worker CPU time or utilization is inferred.

The suggestion is the **smallest eligible tested MAXPROCESS whose estimated whole-pool duration is at most 5% longer than the best measured duration**, adjustable with `--tolerance-percent`. Mathematically, eligible throughput must be at least `best_rate / 1.05`, not simply 95% of the best rate.

Duplicate process limits are permitted, for example `--processes 20,40,20,40`. For each repeated limit, selection uses its slowest eligible sample to avoid choosing a lucky fast repeat. These are still observations, not statistical confidence bounds. If a later trial fails, earlier eligible results remain available, but the overall report clearly shows that the sequence stopped.

## Interpret the estimate

A ten-minute scan may revisit the same early containers on each run. Containers can differ in size and extent count; server ordering, cache warming, concurrent workloads and HCP behavior can bias the comparison. The estimate assumes the measured subset is representative of the rest of the pool. It has no guaranteed error bound.

Do not sum completed counts from separate trials as if they were unique audited objects. Trial scopes can overlap. For important tuning decisions, repeat candidate settings in a different order and compare with a longer sample before using the selected limit for the final full audit.

`VALIDATECLOUDEXTENTS=YES` is the default and should match the subsequent full audit. `--validate-cloud-extents no` permits metadata-only performance trials, explicitly recorded in the result. Rates from that setting are not estimates for an extent-validating audit. `BEGINDATE`/`ENDDATE` filter containers by their last-audit date; they are not timers and are not used to implement the sample duration.

## Output files

| File | Contents |
|---|---|
| `REPORT.txt` | Trial summary, suggested tested limit and scope limitations |
| `benchmark_trials.csv` | Durations, successful/failed counts, rates, per-process ratios and ETAs |
| `benchmark_result.json` | Overall status, settings, trial results and recommendation |
| `trial_01.json`, etc. | Timestamped progress observations, visible linked workers and trial result |
| `before/` | Single initial pool/namespace/container inventory |
| `raw/`, `commands.json` | Submission IDs, progress queries, cancellation and follow-up responses |
| `client_profile.json` | Actual client starts and submitted command counts |
| `SHA256SUMS.txt` | File integrity checksums |

This output is **performance-sampling evidence only**. After choosing a limit, run the existing full `audit` mode and retain that separate report for integrity/change evidence. `compare_audits.py` continues to compare completed full-audit reports; it does not accept benchmark reports.

## AIX 7.3

Keep all three operational Python files together. Use a Python interpreter with the standard-library SQLite module and an installed `dsmadmc` supporting `-credentialsfile`. Prefer the available supported Python 3 installation. The code also preserves Python 2.7 syntax compatibility; native Python 2 execution has not been tested here.

```bash
python3 sp_hcp_audit.py inventory \
  --dsmadmc /usr/tivoli/tsm/client/ba/bin64/dsmadmc \
  --out ./aix_inventory
```

Use the actual installed binary path if different. The toolkit searches PATH and then the typical Linux/AIX locations. It uses the existing client configuration and TLS setup. `-language=AMENG` is not passed; configure the client to produce English output because parsers use English labels. C locale and explicit date/number formatting remain in place.

AIX automatically uses a private temporary directory (0700) and credential file (0600), instead of Linux `/proc/self/fd`. The named file is removed on normal completion and handled exceptions/signals. SIGKILL and power loss can leave it behind. Choose the OS temporary directory through your normal `TMPDIR` configuration if needed; do not point it at an insecure shared mount. Passwords are never passed in argv or stored in reports.

Portability checks cover the AIX selection branch, permissions, credential transport and cleanup using a Linux test runner. A native AIX 7.3 / IBM client integration run is still required. This is code portability, not a new IBM product support certification.

## Fictional example — not a measured benchmark

Assume 29,440 containers and six samples of exactly 600 seconds:

| MAXPROCESS | Successful containers | Containers/hour | Containers per configured process | Estimated full pool |
|---:|---:|---:|---:|---:|
| 10 | 1,600 | 9,600 | 160.000 | 03:04:00 |
| 20 | 2,800 | 16,800 | 140.000 | 01:45:09 |
| 40 | 4,000 | 24,000 | 100.000 | 01:13:36 |
| 60 | 4,120 | 24,720 | 68.667 | 01:11:27 |
| 80 | 4,160 | 24,960 | 52.000 | 01:10:46 |
| 99 | 4,180 | 25,080 | 42.222 | 01:10:26 |

The suggestion is **40**: its estimated duration is **4.5% longer** than the best observed rate at 99, within the 5% tolerance. It uses a lower configured limit; actual DB load reduction is not measured. These invented counts illustrate the calculation only.
