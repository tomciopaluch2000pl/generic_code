# Fictional output walkthrough

**All servers, namespaces, quantities, dates and timings below are invented. These are training examples, not measured IBM/HCP performance or evidence for a real deletion.** The `examples/` directory contains corresponding machine-readable output, including complete synthetic container lists. It is an output-format illustration; it omits the full command journal and some raw responses that a real run retains.

## 1. Collect the instance inventory

```bash
python sp_hcp_audit.py inventory --out ./inventory_20260907
```

The only interactive inputs are:

```text
dsmadmc login: example_admin
dsmadmc password:
```

The password is not echoed. In this example, two reusable clients submit six commands for both cloud pools together.

Simplified view of `before/stgpools.csv`:

| Storage pool | Connection | Namespace | Cloud URL | Cloud containers | SP utilized MB | TiB assuming binary MB |
|---|---|---|---|---:|---:|---:|
| HCP_POOL_A | CONN_HCP_A | archive-n1 | https://hcp-amer.example.test | 24,000 | 12,288,000 | 11.718750 |
| HCP_POOL_B | CONN_HCP_B | archive-n2 | https://hcp-amer.example.test | 8,000 | 4,096,000 | 3.906250 |

This is SP-reported usage. It does not include an inferred second DR copy or claim to be total HCP physical usage.

The namespace files are:

```text
before/namespace_lists/archive-n1__https_hcp-amer.example.test__84e3eed3f7bb.txt
before/namespace_lists/archive-n2__https_hcp-amer.example.test__3106a2087f32.txt
```

The first file has 24,000 lines. Its first three lines are:

```text
archive-n1/example-server-guid/0000000000.dcf
archive-n1/example-server-guid/0000000001.dcf
archive-n1/example-server-guid/0000000002.dcf
```

There is no header in a container list. Each line preserves the full SP container identifier. `before/namespaces.csv` links each target to its list.

## 2. Run one pool-wide audit

```bash
python sp_hcp_audit.py audit HCP_POOL_A --maxprocess 16 --out ./audit_mp16
```

The script submits this single audit command:

```text
AUDIT CONTAINER STGPOOL=HCP_POOL_A ACTION=SCANALL VALIDATECLOUDEXTENTS=YES MAXPROCESS=16 WAIT=YES
```

IBM schedules the server-side processes. The script does not start 16 local `dsmadmc` clients or submit 24,000 audit commands. It normally starts three clients over the complete audit workflow, because the CSV session is reopened after the long audit.

Extract from the fictional `REPORT.txt`:

```text
Server: SP_EXAMPLE_01
Mode: audit
Scope: HCP_POOL_A

AUDIT RESULT: COMPLETED_CLEAN
Configured MAXPROCESS: 16
Audit started UTC: 2026-09-07T10:00:00Z
Audit ended UTC: 2026-09-07T12:17:40Z
Audit duration: 02:17:40 (8260.000 seconds)
Timing basis: command_send_to_final_prompt
Completed containers per minute: 174.334
Inspected extents per second: 2324.455
Containers before / correlated completions / after: 24000 / 24000 / 24000
Extents inspected / marked damaged / marked orphaned: 19200000 / 0 / 0
Reasons: none
```

`timings.csv` separately shows 8,643.5 seconds for `workflow_to_report`, including inventories and evidence processing. That is about 2 hours 24 minutes; the audit itself took 2 hours 17 minutes 40 seconds. Do not add the overall workflow time to the individual phases.

The same result is available in `audit_result.json` and `audit_performance.csv`. `audit_container_results.csv` contains 24,000 correlated completion records. `audit_containers_without_completion.csv` and `audit_inventory_changes.csv` contain only their headers in this clean example.

If even one expected container lacks a correlated completion, the result becomes `REVIEW_REQUIRED` with `MISSING_CORRELATED_CONTAINER_COMPLETIONS`. If the client disconnects before completing collection, the run is `INCOMPLETE_OUTCOME_UNKNOWN`; the observed duration is not presented as proof that the server audit finished.

## 3. Compare independently collected runs

```bash
python compare_audits.py ./audit_mp8 ./audit_mp16 ./audit_mp24 ./audit_mp32 \
  --out ./comparison.csv
```

Fictional runs with the same recorded 24,000-container inventory:

| MAXPROCESS | Audit duration | Containers/minute | Speedup vs. 8 | Duration reduction vs. 8 |
|---:|---:|---:|---:|---:|
| 8 | 04:12:00 | 95.238 | 1.0000 | 0.000% |
| 16 | 02:17:40 | 174.334 | 1.8305 | 45.370% |
| 24 | 02:08:20 | 187.013 | 1.9636 | 49.074% |
| 32 | 02:12:00 | 181.818 | 1.9091 | 47.619% |

In this invented scenario, 32 is slower than 24. It illustrates why a larger process limit is not necessarily better; it is not a recommendation to use 24 on your server.

Try the comparison without any credentials or server connection:

```bash
python compare_audits.py \
  examples/fictional_comparison/mp8 \
  examples/fictional_comparison/mp16 \
  examples/fictional_comparison/mp24 \
  examples/fictional_comparison/mp32
```

Each example row is marked `FICTIONAL_DATA`. Different inventories, validation settings, timing bases or non-clean results suppress the speedup calculation.

## 4. Check old namespace references for the change report

Prepare `candidates.csv`:

```csv
namespace,cloud_url
archive-old,https://hcp-amer.example.test
archive-n1,https://hcp-amer.example.test
```

Run a full-instance inventory:

```bash
python sp_hcp_audit.py inventory --candidates candidates.csv --out ./namespace_review
```

Simplified fictional `candidate_namespaces.csv`:

| Namespace | Exact container references | Exact connections | Observation |
|---|---:|---|---|
| archive-old | 0 | none | NO_REFERENCE_FOUND_IN_THIS_INSTANCE_SCOPE |
| archive-n1 | 24,000 | CONN_HCP_A | REFERENCE_OR_CONFIGURATION_PRESENT |

Both rows have `deletion_assessment=NOT_DETERMINED`. The inventory proves neither absence of another consumer nor completeness of an earlier migration.

Example wording for an operational change report, using only these fictional observations:

> The retained HCP_POOL_A audit completed with 24,000 of 24,000 container completions correlated, 19,200,000 extents inspected and zero final damaged/orphaned counters. MAXPROCESS was 16 and the observed audit duration was 02:17:40. A separate full-instance inventory found no container reference or connection definition for archive-old at the specified endpoint. Migration completeness, application retrieval and references from other instances/consumers require separate evidence before approving removal.

Attach the full actual output directories, their checksums, and that separate reconciliation evidence to the change. A real handover should identify the server, pool, endpoint and observation dates explicitly, as these examples do.
